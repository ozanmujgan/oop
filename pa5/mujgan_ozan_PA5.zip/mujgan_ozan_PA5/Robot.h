#ifndef ROBOT_H
#define ROBOT_H

using namespace std;
#include <iostream>
#include <cstdlib>
#include <ctime>

// Base Robot class
class Robot {
protected:
    int strength; // Robot's strength
    int hitpoints; // Robot's hit points
    string robot_name; // Robot's name
    bool moved; // Flag indicating whether the robot has moved

public:
    Robot(int str, int hp); // Constructor
    virtual ~Robot(); // Destructor
    virtual int getDamage(); // Calculate damage inflicted by the robot
    virtual string getType(); // Get the type of the robot
    int getStrength(); // Get the strength of the robot
    int getHitPoints(); // Get the hit points of the robot
    void setHitPoints(int hp); // Set the hit points of the robot
    void setName(string name); // Set the name of the robot
    string getName(); // Get the name of the robot
    bool isDead(); // Check if the robot is dead
    void setMoved(bool flag); // Set the moved flag for the robot
    bool isMoved() const; // Check if the robot has moved
};

// Humanic robot class, derived from Robot
class Humanic : public Robot {
public:
    Humanic(int str, int hp); // Constructor
    virtual ~Humanic(); // Destructor
    virtual int getDamage(); // Calculate damage inflicted by the humanic robot
    virtual string getType(); // Get the type of the humanic robot
};

// OptimusPrime robot class, derived from Humanic
class OptimusPrime : public Humanic {
public:
    OptimusPrime(); // Constructor
    virtual ~OptimusPrime(); // Destructor
    virtual int getDamage() override; // Calculate damage inflicted by OptimusPrime
    virtual string getType() override; // Get the type of OptimusPrime
};

// RoboCop robot class, derived from Humanic
class RoboCop : public Humanic {
public:
    RoboCop(); // Constructor
    virtual ~RoboCop(); // Destructor
    virtual string getType() override; // Get the type of RoboCop
    virtual int getDamage() override; // Calculate damage inflicted by RoboCop
};

// Roomba robot class, derived from Robot
class Roomba : public Robot {
public:
    Roomba(); // Constructor
    virtual ~Roomba(); // Destructor
    virtual int getDamage() override; // Calculate damage inflicted by Roomba
    virtual string getType() override; // Get the type of Roomba
};

// Bulldozer robot class, derived from Robot
class Bulldozer : public Robot {
public:
    Bulldozer(); // Constructor
    virtual ~Bulldozer(); // Destructor
    virtual int getDamage() override; // Calculate damage inflicted by Bulldozer
    virtual string getType() override; // Get the type of Bulldozer
};

#endif // ROBOT_H
