#include "Robot.h"

Robot::Robot(int str, int hp) : strength(str), hitpoints(hp) {}

Robot::~Robot() {}

int Robot::getDamage() {
    // Generate random damage within the robot's strength range
    int damage = (rand() % strength) + 1;
    cout << getName() << " attacks for " << damage << " points!" << endl;
    return damage; 
}

string Robot::getType() {
    return "unknown";
}

int Robot::getStrength() {
    return strength;
}

int Robot::getHitPoints() {
    return hitpoints;
}

void Robot::setHitPoints(int hp) {
    hitpoints = hp;
}

void Robot::setName(string name) {
    robot_name = name;
}

string Robot::getName() {
    return robot_name;
}

bool Robot::isDead() {
    return hitpoints <= 0;
}

void Robot::setMoved(bool flag) {
    moved = flag;
}

bool Robot::isMoved() const {
    return moved;
}


Humanic::Humanic(int str, int hp) : Robot(str, hp) {}

Humanic::~Humanic() {}

int Humanic::getDamage() {
    int damage = Robot::getDamage();
    // Perform special attack with a 1 in 10 chance
    if (rand() % 10 == 0) {
        cout << getName() << " inflicts tactical nuke attack!" << endl;
        damage += 50;
    }
    return damage;
}

string Humanic::getType() {
    return "Humanic";
}


OptimusPrime::OptimusPrime() : Humanic(100, 100) {}

OptimusPrime::~OptimusPrime() {}

int OptimusPrime::getDamage() {
    int damage = Humanic::getDamage();
    // Perform stronger attack with a 1 in 15 chance
    if (rand() % 15 == 0) {
        
        damage *= 2;
    }
    return damage;
}

string OptimusPrime::getType() {
    return "OptimusPrime";
}


RoboCop::RoboCop() : Humanic(30, 40) {}

RoboCop::~RoboCop() {}

string RoboCop::getType() {
    return "RoboCop";
}

int RoboCop::getDamage() { 
    int damage = Humanic::getDamage();
    // Perform special attack with a 1 in 10 chance
    if (rand() % 10 == 0) {
        cout << "Tactical nuke attack!" << endl;
        damage += 50;
    }
    return damage; 
}



Roomba::Roomba() : Robot(3, 10) {}

Roomba::~Roomba() {}

int Roomba::getDamage() {
    return Robot::getDamage();
}

string Roomba::getType() {
    return "Roomba";
}


Bulldozer::Bulldozer() : Robot(50, 200) {}

Bulldozer::~Bulldozer() {}

int Bulldozer::getDamage() { 
    // Generate random damage within the bulldozer's strength range
    int damage = (rand() % strength) + 1;
    
    return damage; 
}

string Bulldozer::getType() {
    return "Bulldozer";
}
