#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "Robot.h"

using namespace std;

// Function to display the hit message
void hit_message(Robot* attacker, Robot* victim, int damage);

// Function to move the robot and handle fights
void moveRobot(Robot* R, int currentX, int currentY, int newX, int newY, Robot*** grid);

int main() {
    const int GRID_SIZE = 10;
    int NUM_ROBOTS = 20;
    int x, y;
    srand(time(NULL));

    // Create the grid
    Robot*** grid = new Robot**[GRID_SIZE];
    for (int i = 0; i < GRID_SIZE; i++) {
        grid[i] = new Robot*[GRID_SIZE];
        for (int j = 0; j < GRID_SIZE; j++) {
            grid[i][j] = nullptr;
        }
    }

    // Create robot objects and place them on the grid
    Robot** robots = new Robot*[NUM_ROBOTS];

    // Create 5 OptimusPrime robots
    for (int i = 0; i < 5; i++) {
        robots[i] = new OptimusPrime();
        x = rand() % GRID_SIZE;
        y = rand() % GRID_SIZE;

        // Find an empty cell to place the robot
        while (grid[x][y] != nullptr) {
            x = rand() % GRID_SIZE;
            y = rand() % GRID_SIZE;
        }

        // Place the robot on the grid
        grid[x][y] = robots[i];
    }

    // Set names for the OptimusPrime robots
    robots[0]->setName("optimus_prime_0");
    robots[1]->setName("optimus_prime_1");
    robots[2]->setName("optimus_prime_2");
    robots[3]->setName("optimus_prime_3");
    robots[4]->setName("optimus_prime_4");

    // Create 5 RoboCop robots
    for (int i = 0; i < 5; i++) {
        robots[i + 5] = new RoboCop();
        x = rand() % GRID_SIZE;
        y = rand() % GRID_SIZE;

        // Find an empty cell to place the robot
        while (grid[x][y] != nullptr) {
            x = rand() % GRID_SIZE;
            y = rand() % GRID_SIZE;
        }

        // Place the robot on the grid
        grid[x][y] = robots[i + 5];
    }

    // Set names for the RoboCop robots
    robots[5]->setName("robocop_0");
    robots[6]->setName("robocop_1");
    robots[7]->setName("robocop_2");
    robots[8]->setName("robocop_3");
    robots[9]->setName("robocop_4");

    // Create 5 Bulldozer robots
    for (int i = 0; i < 5; i++) {
        robots[i + 10] = new Bulldozer();
        x = rand() % GRID_SIZE;
        y = rand() % GRID_SIZE;

        // Find an empty cell to place the robot
        while (grid[x][y] != nullptr) {
            x = rand() % GRID_SIZE;
            y = rand() % GRID_SIZE;
        }

        // Place the robot on the grid
        grid[x][y] = robots[i + 10];
    }

    // Set names for the Bulldozer robots
    robots[10]->setName("bulldozer_0");
    robots[11]->setName("bulldozer_1");
    robots[12]->setName("bulldozer_2");
    robots[13]->setName("bulldozer_3");
    robots[14]->setName("bulldozer_4");

    // Create 5 Roomba robots
    for (int i = 0; i < 5; i++) {
        robots[i + 15] = new Roomba();
        x = rand() % GRID_SIZE;
        y = rand() % GRID_SIZE;

        // Find an empty cell to place the robot
        while (grid[x][y] != nullptr) {
            x = rand() % GRID_SIZE;
            y = rand() % GRID_SIZE;
        }

        // Place the robot on the grid
        grid[x][y] = robots[i + 15];
    }

    // Set names for the Roomba robots
    robots[15]->setName("roomba_0");
    robots[16]->setName("roomba_1");
    robots[17]->setName("roomba_2");
    robots[18]->setName("roomba_3");
    robots[19]->setName("roomba_4");

    // Print the initial grid
    cout << "Current grid:" << endl;
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            if (grid[i][j] != nullptr) {
                cout << grid[i][j]->getName();
            } 
            cout << " ";
        }
        cout << endl;
    }

    // Visit every cell of the grid
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            Robot* R = grid[i][j];
            if (R != nullptr && !R->isMoved()) { // Check if the cell is occupied by a robot and if the robot has already moved
                R->setMoved(true); // Mark the robot as moved

                // Try to move up
                if (i > 0 && grid[i - 1][j] == nullptr) {
                    moveRobot(R, i, j, i - 1, j, grid); // Move the robot
                }

                // Try to move down
                if (i < GRID_SIZE - 1 && grid[i + 1][j] == nullptr) {
                    moveRobot(R, i, j, i + 1, j, grid); // Move the robot
                }

                // Try to move left
                if (j > 0 && grid[i][j - 1] == nullptr) {
                    moveRobot(R, i, j, i, j - 1, grid); // Move the robot
                }

                // Try to move right
                if (j < GRID_SIZE - 1 && grid[i][j + 1] == nullptr) {
                    moveRobot(R, i, j, i, j + 1, grid); // Move the robot
                }
            }
        }
    }

    // Reset the moved flag for all robots after the round is finished
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            Robot* R = grid[i][j];
            if (R != nullptr) {
                R->setMoved(false);
            }
        }
    }

        // Clean up memory
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            delete grid[i][j];
        }
        delete[] grid[i];
    }
    delete[] grid;

    for (int i = 0; i < NUM_ROBOTS; i++) {
        delete robots[i];
    }
    delete[] robots;

    return 0;
}
// Function to move the robot and handle fights
void moveRobot(Robot* R, int currentX, int currentY, int newX, int newY, Robot*** grid) {
    grid[currentX][currentY] = nullptr; // Clear the current cell
    grid[newX][newY] = R; // Move the robot to the new cell
   
    // Check if there is a robot in the new cell
    Robot* S = grid[newX][newY];
    if (S != nullptr) {
        while (!R->isDead() && !S->isDead()) {
            int d_r = R->getDamage();
            S->setHitPoints(S->getHitPoints() - d_r);
            hit_message(R, S, d_r);

            if (S->isDead()) {
                grid[newX][newY] = nullptr; // Remove the dead robot from the grid
                return;
            }

            int d_s = S->getDamage();
            R->setHitPoints(R->getHitPoints() - d_s);
            hit_message(S, R, d_s);

            if (R->isDead()) {
                grid[currentX][currentY] = nullptr; // Remove the dead robot from the grid
                return;
            }
        }
    }
}
// Function to print the hit message
void hit_message(Robot* attacker, Robot* victim, int damage) {
    cout << attacker->getName() << "(" << attacker->getHitPoints() << ") hits "
         << victim->getName() << "(" << victim->getHitPoints() + damage << ") with "
         << damage << endl;
    cout << "The new hitpoints of " << victim->getName() << " is " << victim->getHitPoints() << endl;
}


