#include "Catalog.h"

// CatalogEntry implementation

CatalogEntry::CatalogEntry(const std::string& title, const std::string& year)
    : title(title), year(year) {}

CatalogEntry::~CatalogEntry() {}

const std::string& CatalogEntry::getTitle() const {
    return title;
}

const std::string& CatalogEntry::getYear() const {
    return year;
}

// Book implementation

Book::Book(const std::string& title, const std::string& authors, const std::string& year,
           const std::string& tags)
    : CatalogEntry(title, year), authors(authors), tags(tags) {}

std::string Book::getInfo() const {
    return "\"" + getTitle() + "\"" + " \"" + authors + "\"" + " \"" + getYear() + "\"" + " \"" + tags + "\"";
}

const std::string& Book::getAuthors() const {
    return authors;
}

const std::string& Book::getTags() const {
    return tags;
}

// Music implementation

Music::Music(const std::string& title, const std::string& year, const std::string& genre,
             const std::string& artists)
    : CatalogEntry(title, year), genre(genre), artists(artists) {}

std::string Music::getInfo() const {
    return "\"" + getTitle() + "\"" + " \"" + artists + "\"" + " \"" + getYear() + "\"" + " \"" + genre + "\"";
}

const std::string& Music::getGenre() const {
    return genre;
}

const std::string& Music::getArtists() const {
    return artists;
}

// Movie implementation

Movie::Movie(const std::string& title, const std::string& year, const std::string& genre,
             const std::string& director, const std::string& starring)
    : CatalogEntry(title, year), genre(genre), director(director), starring(starring) {}

std::string Movie::getInfo() const {
    return "\"" + getTitle() + "\"" + " \"" + director + "\"" + " \"" + getYear() + "\"" + " \"" + genre + "\"" + " \"" + starring + "\"";
}

const std::string& Movie::getGenre() const {
    return genre;
}

const std::string& Movie::getDirector() const {
    return director;
}

const std::string& Movie::getStarring() const {
    return starring;
}
