#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <cstring>
#include <algorithm>
using namespace std;

// Define classes or data structures for catalog entries (e.g., Book, Music, Movie)

// Base class for catalog entries
class CatalogEntry {
public:
    CatalogEntry(const string& title, const string& year)
        : title(title), year(year) {}

    virtual ~CatalogEntry() {}

    const string& getTitle() const { return title; }
    const string& getYear() const { return year; }

    virtual string getInfo() const = 0;

private:
    string title;
    string year;
};

// Book class derived from CatalogEntry
class Book : public CatalogEntry {
public:
    Book(const string& title,const string& authors, const string& year,
          const string& tags)
        : CatalogEntry(title, year), authors(authors), tags(tags) {}

    string getInfo() const override {
        return "\"" + getTitle() + "\"" +" \""+ authors + "\""+" \"" + getYear() + "\"" +" \""+ tags + "\"";
    }
    const string& getAuthors()const{return authors;}
    const string& getTags()const{return tags;}

private:
    string authors;
    string tags;
};

// Music class derived from CatalogEntry
class Music : public CatalogEntry {
public:
    Music(const string& title, const string& year, const string& genre,
          const string& artists)
        : CatalogEntry(title, year), genre(genre), artists(artists) {}

    string getInfo() const override {
    
        return "\"" + getTitle() + "\"" +" \""+ artists + "\""+" \"" + getYear() + "\"" +" \""+ genre + "\"";
    }
    const string& getGenre()const{return genre;}
    const string& getArtists()const{return artists;}

private:
    string genre;
    string artists;
};

// Movie class derived from CatalogEntry
class Movie : public CatalogEntry {
public:
    Movie(const string& title, const string& year, const string& genre,
          const string& director, const string& starring)
        : CatalogEntry(title, year), genre(genre), director(director), starring(starring) {}

    string getInfo() const override {
        return "\"" + getTitle() + "\"" +" \""+ director + "\""+" \"" + getYear() + "\"" +" \""+ genre + "\"" +" \"" + starring+"\"";
    }
    const string& getGenre()const{return genre;}
    const string& getDirector()const{return director;}
    const string& getStarring()const{return starring;}
    
    

private:
    string genre;
    string director;
    string starring;
};


int main() {
         ifstream dataFile("data.txt");
        ifstream commandsFile("commands.txt");
        ofstream logFile("output.txt");
    try {
       

        if (!dataFile) {
            throw runtime_error("Failed to open file.");
        }

        string catalogType;
        getline(dataFile, catalogType);
        cout << catalogType  << endl;
            // Create the catalog based on the catalog type
        const int MAX_ENTRIES = 100;  // Maximum number of catalog entries
        Movie** mcatalog = new Movie*[MAX_ENTRIES];
        Book** bcatalog = new Book*[MAX_ENTRIES];
        Music** muscatalog = new Music*[MAX_ENTRIES];
        // Read the catalog data from data.txt and populate the catalog
        string line;
        int entryCount = 0;  // Track the number of entries
        if(catalogType=="movie"){
             logFile << "Catalog Read:"<<catalogType << endl;

        while (getline(dataFile, line)) {
        // Parse the line and extract individual fields
        string title, director, year, genre, starring;
        // Example parsing logic for movies
        size_t start = line.find('"');
        size_t end = line.find('"', start + 1);
        title = line.substr(start + 1, end - start - 1);
        start = line.find('"', end + 1);
        end = line.find('"', start + 1);
        director = line.substr(start + 1, end - start - 1);
        start = line.find('"', end + 1);
        end = line.find('"', start + 1);
        year = line.substr(start + 1, end - start - 1);
        start = line.find('"', end + 1);
        end = line.find('"', start + 1);
        genre = line.substr(start + 1, end - start - 1);
        start = line.find('"', end + 1);
        end = line.find('"', start + 1);
        starring = line.substr(start + 1, end - start - 1);
       
        // Create a movie object and add it to the catalog
        Movie* movie = new Movie(title, year, genre, director, starring);
        mcatalog[entryCount] = movie;
        entryCount++;
        char c;
        int quoteCount=0;
            for (size_t i = 0; i < line.length(); i++) {
            if (line[i] == '"') {
                quoteCount++;
            }
        }
        if (quoteCount!=10)
        {
            logFile<<"Exception: missing field"<<endl;
            logFile<<mcatalog[entryCount-1]->getInfo()<<endl;
        }

        // Check if the maximum number of entries has been reached
        if (entryCount >= MAX_ENTRIES) {
        return 0;
        }

    }
   

    int uniq=entryCount;

    for (int i = 0; i < entryCount; i++) {
        
      for(int j=i+1;j<entryCount;j++){
          try{
          if(mcatalog[i]->getTitle()==mcatalog[j]->getTitle()){
              throw 1;
           
          }
          }
          catch(int a){
              if(a==1){
                  logFile<<"Exception: duplicate entry"<<endl;
                   logFile<<mcatalog[i]->getInfo()<<endl;
                   uniq--;
              }
          }
      }
    }
    logFile<<uniq<<" unique entries"<<endl;





    string command;
    while (getline(commandsFile, command)) {
        istringstream iss(command);

        string cmd;
        iss >> cmd;

        if (cmd == "search") {
    string searchString, inKeyword, field;
    iss >> searchString >> inKeyword >> field;
        searchString = searchString.substr(1, searchString.length() - 2);
        field=field.substr(1,field.length()-2);
    // Process the search command using the searchString and field values
    // Implement your search logic here

    // Iterate through the catalog entries
    for (int i = 0; i < entryCount; i++) {
        Movie* entry = mcatalog[i];

        // Check if the field matches the specified field
        if (field == "title") {
            // Search in the "title" field using the searchString
            if (entry->getTitle().find(searchString) != string::npos) {
                // Match found, output the entry
                logFile<<cmd<<" "<<'"'<<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                logFile << entry->getInfo() << endl;
                break;
                }
            } 
             else if (field == "year") {
            // Search in the "title" field using the searchString
                if (entry->getYear().find(searchString) != string::npos) {
                // Match found, output the entry
                logFile<<cmd<<" "<<'"'<<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                logFile << entry->getInfo() << endl;
                break;
                }
            } 
             else if (field == "genre") {
            // Search in the "title" field using the searchString
            if (entry->getGenre().find(searchString) != string::npos) {
                // Match found, output the entry
                logFile<<cmd<<" "<<'"'<<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                logFile << entry->getInfo() << endl;
                break;
                }
            } 
             else if (field == "director") {
            // Search in the "title" field using the searchString
            if (entry->getDirector().find(searchString) != string::npos) {
                // Match found, output the entry
                logFile<<cmd<<" "<<'"'<<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                logFile << entry->getInfo() << endl;
                break;
                }
            }     
             else if (field == "starring") {
            // Search in the "title" field using the searchString
            if (entry->getStarring().find(searchString) != string::npos) {
                // Match found, output the entry
                logFile<<cmd<<" "<<'"'<<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                logFile << entry->getInfo() << endl;
                break;
                }
            }
            else{
                logFile<<"Exception: command is wrong"<<endl;
                logFile<<cmd<<'"' <<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                break;
            } 
        
        
        }
    }

     else if (cmd == "sort") {
        string sortField;
        iss >> sortField;
        sortField=sortField.substr(1,sortField.length()-2);
        // Process the sort command using the sortField value
       
        if (sortField == "title") {
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
             sort(mcatalog, mcatalog + entryCount, [](const Movie* a, const Movie* b) {
            return a->getTitle() < b->getTitle();
            });

            string previousTitle;
            for (int i = 0; i < entryCount; ++i) {
            if (mcatalog[i]->getTitle() != previousTitle) {
                logFile << mcatalog[i]->getInfo() << endl;
                previousTitle = mcatalog[i]->getTitle();
            }
            }
        }
        else if (sortField == "year") {
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
             sort(mcatalog, mcatalog + entryCount, [](const Movie* a, const Movie* b) {
            return a->getYear() < b->getYear();
            });

            string previousTitle;
            for (int i = 0; i < entryCount; ++i) {
            if (mcatalog[i]->getYear() != previousTitle) {
                logFile << mcatalog[i]->getInfo() << endl;
                previousTitle = mcatalog[i]->getYear();
            }
            }
            } 
             else if (sortField == "genre") {
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
             sort(mcatalog, mcatalog + entryCount, [](const Movie* a, const Movie* b) {
            return a->getGenre() < b->getGenre();
            });

            string previousTitle;
            for (int i = 0; i < entryCount; ++i) {
            if (mcatalog[i]->getGenre() != previousTitle) {
                logFile << mcatalog[i]->getInfo() << endl;
                previousTitle = mcatalog[i]->getGenre();
            }
            }
            } 
             else if (sortField == "director") {
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
             sort(mcatalog, mcatalog + entryCount, [](const Movie* a, const Movie* b) {
            return a->getDirector() < b->getDirector();
            });

            string previousTitle;
            for (int i = 0; i < entryCount; ++i) {
            if (mcatalog[i]->getDirector() != previousTitle) {
                logFile << mcatalog[i]->getInfo() << endl;
                previousTitle = mcatalog[i]->getDirector();
            }
            }
            }     
             else if (sortField == "starring") {
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
             sort(mcatalog, mcatalog + entryCount, [](const Movie* a, const Movie* b) {
            return a->getStarring() < b->getStarring();
            });

            string previousTitle;
            for (int i = 0; i < entryCount; ++i) {
            if (mcatalog[i]->getStarring() != previousTitle) {
                logFile << mcatalog[i]->getInfo() << endl;
                previousTitle = mcatalog[i]->getStarring();
            }
            }
            }
            else{
                logFile<<"Exception: command is wrong"<<endl;
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
                break;
            } 
        } 
    }


    }
        else if (catalogType=="book")
        {
            logFile << "Catalog Read:"<<catalogType << endl;

        string title,authors,year,tags;
        while(getline(dataFile,line)){
        size_t start = line.find('"');
        size_t end = line.find('"', start + 1);
        title = line.substr(start + 1, end - start - 1);
        start = line.find('"', end + 1);
        end = line.find('"', start + 1);
        authors = line.substr(start + 1, end - start - 1);
        start = line.find('"', end + 1);
        end = line.find('"', start + 1);
        year = line.substr(start + 1, end - start - 1);
        start = line.find('"', end + 1);
        end = line.find('"', start + 1);
        tags = line.substr(start + 1, end - start - 1);

        Book *book= new Book(title,authors,year,tags);
        bcatalog[entryCount] = book;
        entryCount++;
        if (entryCount >= MAX_ENTRIES) {
        return 0;
        }

    }
    int uniq=entryCount;
        for (int i = 0; i < entryCount; i++) {
        
      for(int j=i+1;j<entryCount;j++){
          try{
          if(bcatalog[i]->getTitle()==bcatalog[j]->getTitle()){
              throw 1;
           
          }
          }
          catch(int a){
              if(a==1){
                  logFile<<"Exception: duplicate entry"<<endl;
                   logFile<<bcatalog[i]->getInfo()<<endl;
                   uniq--;
              }
          }
      }
    }
    logFile<<uniq<<" unique entries"<<endl;

    string command;
    while (getline(commandsFile, command)) {
        istringstream iss(command);

        string cmd;
        iss >> cmd;

        if (cmd == "search") {
    string searchString, inKeyword, field;
    iss >> searchString >> inKeyword >> field;
        searchString = searchString.substr(1, searchString.length() - 2);
        field=field.substr(1,field.length()-2);
    // Process the search command using the searchString and field values
    // Implement your search logic here

    // Iterate through the catalog entries
    for (int i = 0; i < entryCount; i++) {
        Book* entry = bcatalog[i];

        // Check if the field matches the specified field
        if (field == "title") {
            // Search in the "title" field using the searchString
            if (entry->getTitle().find(searchString) != string::npos) {
                // Match found, output the entry
                logFile<<cmd<<" "<<'"'<<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                logFile << entry->getInfo() << endl;
                break;
                }
            } 
             else if (field == "year") {
            // Search in the "title" field using the searchString
                if (entry->getYear().find(searchString) != string::npos) {
                // Match found, output the entry
                logFile<<cmd<<" "<<'"'<<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                logFile << entry->getInfo() << endl;
                break;
                }
            } 
             else if (field == "authors") {
            // Search in the "title" field using the searchString
            if (entry->getAuthors().find(searchString) != string::npos) {
                // Match found, output the entry
                logFile<<cmd<<" "<<'"'<<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                logFile << entry->getInfo() << endl;
                break;
                }
            } 
             else if (field == "tags") {
            // Search in the "title" field using the searchString
            if (entry->getTags().find(searchString) != string::npos) {
                // Match found, output the entry
                logFile<<cmd<<" "<<'"'<<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                logFile << entry->getInfo() << endl;
                break;
                }
            }     
            
            else{
                logFile<<"Exception: command is wrong"<<endl;
                logFile<<cmd<<'"' <<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                break;
            } 
        
        
        }
    }

     else if (cmd == "sort") {
        string sortField;
        iss >> sortField;
        sortField=sortField.substr(1,sortField.length()-2);
        // Process the sort command using the sortField value
       
        if (sortField == "title") {
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
             sort(bcatalog, bcatalog + entryCount, [](const Book* a, const Book* b) {
            return a->getTitle() < b->getTitle();
            });

            string previousTitle;
            for (int i = 0; i < entryCount; ++i) {
            if (bcatalog[i]->getTitle() != previousTitle) {
                logFile << bcatalog[i]->getInfo() << endl;
                previousTitle = bcatalog[i]->getTitle();
            }
            }
        }
        else if (sortField == "year") {
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
             sort(bcatalog, bcatalog + entryCount, [](const Book* a, const Book* b) {
            return a->getYear() < b->getYear();
            });

            string previousTitle;
            for (int i = 0; i < entryCount; ++i) {
            if (bcatalog[i]->getYear() != previousTitle) {
                logFile << bcatalog[i]->getInfo() << endl;
                previousTitle = bcatalog[i]->getYear();
            }
            }
            } 
             else if (sortField == "authors") {
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
             sort(bcatalog, bcatalog + entryCount, [](const Book* a, const Book* b) {
            return a->getAuthors() < b->getAuthors();
            });

            string previousTitle;
            for (int i = 0; i < entryCount; ++i) {
            if (bcatalog[i]->getAuthors() != previousTitle) {
                logFile << bcatalog[i]->getInfo() << endl;
                previousTitle = bcatalog[i]->getAuthors();
            }
            }
            } 
             else if (sortField == "tags") {
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
             sort(bcatalog, bcatalog + entryCount, [](const Book* a, const Book* b) {
            return a->getTags() < b->getTags();
            });

            string previousTitle;
            for (int i = 0; i < entryCount; ++i) {
            if (bcatalog[i]->getTags() != previousTitle) {
                logFile << bcatalog[i]->getInfo() << endl;
                previousTitle = bcatalog[i]->getTags();
            }
            }
            }     
           
            else{
                logFile<<"Exception: command is wrong"<<endl;
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
                break;
            } 
        } 
    }



    }


        else if (catalogType=="music")
        {
            logFile << "Catalog Read:"<<catalogType << endl;
        string title,artists,year,genre;
         while(getline(dataFile,line)){
        size_t start = line.find('"');
        size_t end = line.find('"', start + 1);
        title = line.substr(start + 1, end - start - 1);
        start = line.find('"', end + 1);
        end = line.find('"', start + 1);
        artists = line.substr(start + 1, end - start - 1);
        start = line.find('"', end + 1);
        end = line.find('"', start + 1);
        year = line.substr(start + 1, end - start - 1);
        start = line.find('"', end + 1);
        end = line.find('"', start + 1);
        genre = line.substr(start + 1, end - start - 1);

         Music *music= new Music(title,artists,year,genre);
        muscatalog[entryCount] =music;
        entryCount++;
        if (entryCount >= MAX_ENTRIES) {
        return 0;
        }

       
        }
        int uniq=entryCount;
         for (int i = 0; i < entryCount; i++) {
        
            for(int j=i+1;j<entryCount;j++){
          try{
          if(muscatalog[i]->getTitle()==muscatalog[j]->getTitle()){
              throw 1;
           
          }
          }
          catch(int a){
              if(a==1){
                  logFile<<"Exception: duplicate entry"<<endl;
                   logFile<<muscatalog[i]->getInfo()<<endl;
                   uniq--;
              }
          }
        }
        }
        logFile<<uniq<<" unique entries"<<endl;

        string command;
    while (getline(commandsFile, command)) {
        istringstream iss(command);

        string cmd;
        iss >> cmd;

        if (cmd == "search") {
    string searchString, inKeyword, field;
    iss >> searchString >> inKeyword >> field;
        searchString = searchString.substr(1, searchString.length() - 2);
        field=field.substr(1,field.length()-2);
    // Process the search command using the searchString and field values
    // Implement your search logic here

    // Iterate through the catalog entries
    for (int i = 0; i < entryCount; i++) {
        Music* entry = muscatalog[i];

        // Check if the field matches the specified field
        if (field == "title") {
            // Search in the "title" field using the searchString
            if (entry->getTitle().find(searchString) != string::npos) {
                // Match found, output the entry
                logFile<<cmd<<" "<<'"'<<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                logFile << entry->getInfo() << endl;
                break;
                }
            } 
             else if (field == "year") {
            // Search in the "title" field using the searchString
                if (entry->getYear().find(searchString) != string::npos) {
                // Match found, output the entry
                logFile<<cmd<<" "<<'"'<<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                logFile << entry->getInfo() << endl;
                break;
                }
            } 
             else if (field == "artists") {
            // Search in the "title" field using the searchString
            if (entry->getArtists().find(searchString) != string::npos) {
                // Match found, output the entry
                logFile<<cmd<<" "<<'"'<<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                logFile << entry->getInfo() << endl;
                break;
                }
            } 
             else if (field == "genre") {
            // Search in the "title" field using the searchString
            if (entry->getGenre().find(searchString) != string::npos) {
                // Match found, output the entry
                logFile<<cmd<<" "<<'"'<<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                logFile << entry->getInfo() << endl;
                break;
                }
            }     
            
            else{
                logFile<<"Exception: command is wrong"<<endl;
                logFile<<cmd<<'"' <<searchString<<'"'<<inKeyword<<'"'<<field<<'"'<<endl;
                break;
            } 
        
        
        }
    }

     else if (cmd == "sort") {
        string sortField;
        iss >> sortField;
        sortField=sortField.substr(1,sortField.length()-2);
        // Process the sort command using the sortField value
       
        if (sortField == "title") {
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
             sort(muscatalog, muscatalog + entryCount, [](const Music* a, const Music* b) {
            return a->getTitle() < b->getTitle();
            });

            string previousTitle;
            for (int i = 0; i < entryCount; ++i) {
            if (muscatalog[i]->getTitle() != previousTitle) {
                logFile << muscatalog[i]->getInfo() << endl;
                previousTitle = muscatalog[i]->getTitle();
            }
            }
        }
        else if (sortField == "year") {
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
             sort(muscatalog, muscatalog + entryCount, [](const Music* a, const Music* b) {
            return a->getYear() < b->getYear();
            });

            string previousTitle;
            for (int i = 0; i < entryCount; ++i) {
            if (muscatalog[i]->getYear() != previousTitle) {
                logFile << muscatalog[i]->getInfo() << endl;
                previousTitle = muscatalog[i]->getYear();
            }
            }
            } 
             else if (sortField == "artists") {
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
             sort(muscatalog, muscatalog + entryCount, [](const Music* a, const Music* b) {
            return a->getArtists() < b->getArtists();
            });

            string previousTitle;
            for (int i = 0; i < entryCount; ++i) {
            if (muscatalog[i]->getArtists() != previousTitle) {
                logFile << muscatalog[i]->getInfo() << endl;
                previousTitle = muscatalog[i]->getArtists();
            }
            }
            } 
             else if (sortField == "genre") {
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
             sort(muscatalog, muscatalog + entryCount, [](const Music* a, const Music* b) {
            return a->getGenre() < b->getGenre();
            });

            string previousTitle;
            for (int i = 0; i < entryCount; ++i) {
            if (muscatalog[i]->getGenre() != previousTitle) {
                logFile << muscatalog[i]->getInfo() << endl;
                previousTitle = muscatalog[i]->getGenre();
            }
            }
            }     
           
            else{
                logFile<<"Exception: command is wrong"<<endl;
                logFile<<cmd<<" "<<'"'<<sortField<<'"'<<endl;
                break;
            } 
        } 
    }



    }
      

    }
     catch (int  e) {
         
      return 0;
      
        
    }
    


    return 0;
}
