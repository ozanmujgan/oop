#ifndef CATALOG_H
#define CATALOG_H

#include <string>
using namespace std;

class CatalogEntry {
public:
    CatalogEntry(const string& title, const string& year);
    virtual ~CatalogEntry();

    const string& getTitle() const;
    const string& getYear() const;

    virtual string getInfo() const = 0;

private:
    string title;
    string year;
};

class Book : public CatalogEntry {
public:
    Book(const string& title, const string& authors, const string& year,
         const string& tags);

    string getInfo() const override;
    const string& getAuthors() const;
    const string& getTags() const;

private:
    string authors;
    string tags;
};

class Music : public CatalogEntry {
public:
    Music(const string& title, const string& year, const string& genre,
          const string& artists);

    string getInfo() const override;
    const string& getGenre() const;
    const string& getArtists() const;

private:
    string genre;
    string artists;
};

class Movie : public CatalogEntry {
public:
    Movie(const string& title, const string& year, const string& genre,
          const string& director, const string& starring);

    string getInfo() const override;
    const string& getGenre() const;
    const string& getDirector() const;
    const string& getStarring() const;

private:
    string genre;
    string director;
    string starring;
};
#endif // CATALOG_H