#include "Student.h"
#include <iostream>
#include <string>


using namespace std;

namespace PA4{
// Parameterized constructor
Student::Student(const string& name, const string& id) {
    this->name = name;
    this->id = id;
    // Allocate memory for an array of Course pointers with size 0
    courses = new Course*[0];
    for (int i = 0; i <=0; i++) {
        courses[i] = nullptr;
    }
}
// Destructor to deallocate memory used by the courses array
Student::~Student() {
    for (int i = 0; courses[i]!= nullptr; i++) {
        
            delete courses[i];
    
    }
    delete[] courses;
}
//get and set functions
string Student::getName() const {
    return name;
}

void Student::setName(const string& name) {
    this->name = name;
}
// Getter function for the Student object's ID
string Student::getID() const {
    return id;
}
// Setter function for the Student object's ID
void Student::setID(const string& id) {
    this->id = id;
}
// Function to add a Course object to the courses array
void Student::addCourse(int courseCount) {
    string courseCode, courseName;
    
    cin >> courseCode;
    
    cin>>courseName;
    for (int i = 0; i < courseCount; i++) {
        if (courses[i] == nullptr) {
            courses[i] = new Course(courseCode, courseName);
            
            return;
        }
    }
   
}
// Function to delete a Course object from the courses array
void Student::deleteCourse(int courseCount) {
    string courseCode;
    
    cin >> courseCode;
    for (int i = 0; i < courseCount; i++) {
        // If a Course object with the matching course code is found, delete it and set the current element of the courses array to nullptr
        if (courses[i] != nullptr && courses[i]->getCode() == courseCode) {
            delete courses[i];
            courses[i] = nullptr;
            
            return;
        }
    }
    
}
// Function to list all students registered to a specific course
void Student::listStudentsRegisteredToCourse(int courseCount) {
    string courseCode;
    cout << "Enter course code: ";
    cin >> courseCode;
    for (int i = 0; i < courseCount; i++) {
        // If a Course object with the matching course code is found, call its listAllStudents function
        if (courses[i] != nullptr && courses[i]->getCode() == courseCode) {
            courses[i]->listAllStudents(courseCount);
            return;
        }
    }
    
}
// Function to list all courses in the courses array
void Student::listAllCourses(int courseCount) {
    bool hasCourses = false;
    for (int i = 0; i < courseCount; i++) {
        if (courses[i] != nullptr) {
            cout << "Course code: " << courses[i]->getCode() << " - Course name: " << courses[i]->getName() << endl;
            hasCourses = true;
        }
    }
    if (!hasCourses) {
      
    }
}

}