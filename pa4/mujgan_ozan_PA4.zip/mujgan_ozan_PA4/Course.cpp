#include "Course.h"
#include "SchoolManagerSystem.h"
using namespace std;
#include <iostream>
#include <string>

namespace PA4{

    // Default constructor
    Course::Course() {
    name = "";
    code = "";
   
}
// Parameterized constructor
Course::Course(const string& name, const string& code) {
    this->name = name;
    this->code = code;
    // Initialize students array with 0 elements and nullptr values
    students = new Student*[0];
    for (int i = 0; i <=0; i++) {
        students[i] = nullptr;
    }
}
// Destructor

Course::~Course() {
    for (int i = 0; students[i]!=nullptr; i++) {
        
            delete students[i];
        
    }
    // Deallocate memory for students array
    delete[] students;
}
// Getters and setters for name and code
string Course::getName() const {
    return name;
}

void Course::setName(const string& name) {
    this->name = name;
}

string Course::getCode() const {
    return code;
}

void Course::setCode(const string& code) {
    this->code = code;
}
//  add a new student
void Course::addStudent(int studentCount) {
    string name;
    string id;
    
    cin>>name;
    
    cin >> id;
    // Find the first empty slot in students array and add the new student
    for (int i = 0; i < studentCount; i++) {
        if (students[i] == nullptr) {
            students[i] = new Student(name, id);
            
            return;
        }
    }
  
}
// Method to delete a student from the course
void Course::deleteStudent(int studentCount) {
    string id;
    // Get ID of the student to be deleted from user input
    cin >> id;
    // Find the student with the matching ID and delete it
    for (int i = 0; i < studentCount; i++) {
        if (students[i] != nullptr && students[i]->getID() == id) {
            delete students[i];
            students[i] = nullptr;
            
            return;
        }
    }
    
}
// Method to add a selected student to the course
void Course::addSelectedStudentToCourse(Student* student,int studentCount) {
    // Find the first empty slot in students array and add the selected student
    for (int i = 0; i < studentCount; i++) {
        if (students[i] == nullptr) {
            students[i] = student;
            
            return;
        }
    }
  
}

void Course::dropSelectedStudentFromCourse(Student* student,int studentCount) {
    for (int i = 0; i < studentCount; i++) {
        if (students[i] == student) {
            students[i] = nullptr;
            
            return;
        }
    }
   
}

void Course::listAllStudents(int studentCount) {
    cout << "Students in " << name << " (" << code << "):\n";
    for (int i = 0; i < studentCount; i++) {
        if (students[i] != nullptr) {
            cout << students[i]->getName() << " (" << students[i]->getID() << ")\n";
        }
    }
}

}
