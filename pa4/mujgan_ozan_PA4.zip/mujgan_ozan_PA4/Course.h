#ifndef COURSE_H
#define COURSE_H
#include <iostream>
#include <string>
#include "SchoolManagerSystem.h"
#include "Student.h"
using namespace std;
namespace PA4{
class Student;
class Course {
public:
    Course();
    Course(const string& name, const string& code);
    ~Course();

    string getName() const;
    void setName(const string& name);
    string getCode() const;
    void setCode(const string& code);


    void addStudent(int studentCount);
    void deleteStudent(int studentCount);
    void addSelectedStudentToCourse(Student* student,int studentCount);
    void dropSelectedStudentFromCourse(Student* student,int studentCount);
    void listAllStudents(int studentCount);

private:
    string name;
    string code;
    Student** students;
};
}
#endif
