#include "SchoolManagerSystem.h"
#include <iostream>
using namespace PA4;
int main() {
    SchoolManagerSystem school;

  	school.run();

    return 0;
}
