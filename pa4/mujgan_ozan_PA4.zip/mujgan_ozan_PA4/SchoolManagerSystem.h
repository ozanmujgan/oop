#ifndef SCHOOLMANAGEMENTSYSTEM_H
#define SCHOOLMANAGEMENTSYSTEM_H

#include <string>
#include "Student.h"
#include "Course.h"
namespace PA4{
class SchoolManagerSystem
{
public:
    SchoolManagerSystem();
    void run();


    ~SchoolManagerSystem();

private:
    int studentCount; 
    int courseCount; 
};
}
#endif // SCHOOLMANAGEMENTSYSTEM_H

