#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>
#include <string>
#include "Course.h"
using namespace std;
namespace PA4{
class Course;
class Student {
public:
    Student() {
    name = "";
    id = "";
    
    }
    Student(const string& name, const string& id);
    ~Student();

    string getName() const;
    void setName(const string& name);
    string getID() const;
    void setID(const string& id);

    void addCourse(int courseCount);
    void deleteCourse(int courseCount);
    void listStudentsRegisteredToCourse(int courseCount);
    void listAllCourses(int courseCount);
    
    
private:
    string name;
    string id;
    Course** courses;
};
}
#endif
