#include "SchoolManagerSystem.h"
#include "Student.h"
#include "Course.h"
#include <iostream>
#include <cstring>
using namespace std;
namespace PA4{
Student student;
Course course;

Student *s;
Course *c;
    
      SchoolManagerSystem::SchoolManagerSystem() {
        int studentCount = 0;
       int  courseCount = 0;
    }
     SchoolManagerSystem::~SchoolManagerSystem() {
        // destructor implementation
    }

    void SchoolManagerSystem::run() {
        int choice;
        do {
            
                     cout << "0 exit\n"
                      << "1 student\n"
                      << "2 course\n"
                      << "3 list_all_students\n"
                      << "4 list_all_courses\n"
                      << ">> ";
            
            cin >> choice;
            switch (choice) {
                case 0:
                    
                    exit(0);
                    break;
     // Student menu
                case 1:
                    
            cout << "0 up\n"
                      << "1 add_student\n"
                      << "2 select_student\n"
                      << ">> ";
            int select;
            cin >> select;
            switch (select) {
                case 0:
                    // Go back up to the main menu
                    break;
                case 1:
                    // Add a new student
                    studentCount++;
                    course.addStudent(studentCount);
                    break;
                case 2:
                    
            cout << "0 up\n"
                      << "1 delete_student\n"
                      << "2 add_selected_student_to_a_course\n"
                      << "3 drop_selected_student_from_a_course\n"
                      << ">> ";
            int select1;
            cin >> select1;
            switch (select1) {
                case 0:
                    
                    break;
                case 1:
                    // Delete a student
                    course.deleteStudent(studentCount);
                    return;
                case 2:
                      // Add a selected student to a course
                    course.addSelectedStudentToCourse(s,studentCount);
                    break;
                case 3:
                    // Drop a selected student from a course
                    course.dropSelectedStudentFromCourse(s,studentCount);
                    break;
                default:
                   
                    break;
            }
        
                    break;
                default:
                   
                    break;
            }
        

                    break;

            // Course menu
                case 2:
                   
            cout << "0 up\n"
                  << "1 add_course\n"
                  << "2 select_course\n"
                  << ">> ";
            int choice1;
        cin >> choice1;
        switch (choice1) {
            case 0:
                
                break;
            case 1:
                // Add a new course
                courseCount++;
                student.addCourse(courseCount);
                
                break;
            case 2:
                
        cout << "0 up\n"
                  << "1 delete_course \n"
                  << "2 list_students_registered_to_the_selected_course\n"
                  << ">> ";
        int choice2;
        cin >> choice2;
        switch (choice2) {
            case 0:
                
                break;
            case 1:
                // Delete a course
                student.deleteCourse(courseCount);
                return;
            case 2:
                 // List all students registered to the selected course
                student.listStudentsRegisteredToCourse(courseCount);
                break;
            default:
               
                break;
        }
    
                break;

            default:
               
                break;
        }
    
                    break;



                case 3:
                    course.listAllStudents(studentCount);
                    break;
                case 4:
                    student.listAllCourses(courseCount);
                    break;
                default:
                   
                    break;
            }
        } while (choice != 0);
    }

}

    
